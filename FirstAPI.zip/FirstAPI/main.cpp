#if defined(UNICODE) && !defined(_UNICODE)
#define _UNICODE
#elif defined(_UNICODE) && !defined(UNICODE)
#define UNICODE
#endif

#include <windows.h>
#include <tchar.h>
#include "stuff.h"
#include <stdio.h>

/* Declare Windows procedure */
LRESULT CALLBACK WindowProcedure(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK DialogProcedure(HWND, UINT, WPARAM, LPARAM);
void init(HWND);

typedef void (__cdecl *MYPROC)(LPCSTR);
typedef int (__cdecl *MYPROC2)(INT, INT);

TCHAR szClassName[] = _T("CodeBlocksWindowsApp");

int WINAPI WinMain(HINSTANCE hThisInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR lpszArgument,
                   int nCmdShow)
{
    HWND hwnd;
    MSG messages;
    WNDCLASSEX wincl;

    /* The Window structure */
    wincl.hInstance = hThisInstance;
    wincl.lpszClassName = szClassName;
    wincl.lpfnWndProc = WindowProcedure;
    wincl.style = CS_DBLCLKS;
    wincl.cbSize = sizeof(WNDCLASSEX);

    wincl.hIcon = LoadIcon(hThisInstance, MAKEINTRESOURCE(ID_ICON));
    wincl.hIconSm = LoadIcon(hThisInstance, MAKEINTRESOURCE(ID_ICON));
    wincl.hCursor = LoadCursor(NULL, IDC_ARROW);
    wincl.lpszMenuName = NULL;
    wincl.cbClsExtra = 0;
    wincl.cbWndExtra = 0;
    wincl.hbrBackground = (HBRUSH) COLOR_BACKGROUND;

    if (!RegisterClassEx(&wincl))
        return 0;

    hwnd = CreateWindowEx(
               0,
               szClassName,
               _T("My first API"),
               WS_OVERLAPPEDWINDOW,
               100, 100, 544, 375,
               HWND_DESKTOP,
               LoadMenu(NULL, MAKEINTRESOURCE(IDR_MYMENU)),
               hThisInstance,
               NULL
           );

    ShowWindow(hwnd, nCmdShow);

    while (GetMessage(&messages, NULL, 0, 0))
    {
        TranslateMessage(&messages);
        DispatchMessage(&messages);
    }

    return messages.wParam;
}

/* This function initializes buttons and other controls */
void init(HWND hwnd)
{
    CreateWindow(
        "BUTTON",
        "BUTTON_1",
        WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
        10, 10, 100, 100,
        hwnd,
        (HMENU) BUTTON_1,
        (HINSTANCE) GetWindowLongPtr(hwnd, GWLP_HINSTANCE),
        NULL);

    CreateWindow(
        "BUTTON",
        "BUTTON_2",
        WS_CHILD | BS_DEFPUSHBUTTON,
        120, 10, 100, 100,
        hwnd,
        (HMENU) BUTTON_2,
        (HINSTANCE) GetWindowLongPtr(hwnd, GWLP_HINSTANCE),
        NULL);

    CreateWindow(
        "BUTTON",
        "BUTTON_3",
        WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON | WS_DISABLED,
        120, 230, 100, 100,
        hwnd,
        (HMENU) BUTTON_3,
        (HINSTANCE) GetWindowLongPtr(hwnd, GWLP_HINSTANCE),
        NULL);

    CreateWindow(
        "BUTTON",
        "BUTTON_4",
        WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
        120, 120, 100, 100,
        hwnd,
        (HMENU) BUTTON_4,
        (HINSTANCE) GetWindowLongPtr(hwnd, GWLP_HINSTANCE),
        NULL);

    CreateWindow(
        "EDIT",
        "Text",
        WS_VISIBLE | WS_CHILD | WS_BORDER,
        220, 10, 100, 20,
        hwnd,
        (HMENU) EDIT_WINDOW,
        (HINSTANCE) GetWindowLongPtr(hwnd, GWLP_HINSTANCE),
        NULL);
    CreateWindow(
        "EDIT",
        "Text",
        WS_VISIBLE | WS_CHILD | WS_BORDER,
        220, 40, 100, 20,
        hwnd,
        (HMENU) EDIT_WINDOW2,
        (HINSTANCE) GetWindowLongPtr(hwnd, GWLP_HINSTANCE),
        NULL);

    CreateWindow(
        "BUTTON",
        "OK",
        WS_VISIBLE | WS_CHILD | BS_DEFPUSHBUTTON,
        220, 70, 50, 35,
        hwnd,
        (HMENU) BUTTON_5,
        (HINSTANCE) GetWindowLongPtr(hwnd, GWLP_HINSTANCE),
        NULL);
}

/* Main Window Procedure */
LRESULT CALLBACK WindowProcedure(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
    case WM_CREATE:
        init(hwnd);
        break;

    case WM_COMMAND:
        switch (LOWORD(wParam))
        {
        case BUTTON_1:
            ShowWindow(GetDlgItem(hwnd, BUTTON_1), SW_HIDE);
            ShowWindow(GetDlgItem(hwnd, BUTTON_2), SW_SHOW);
            break;

        case BUTTON_2:
            ShowWindow(GetDlgItem(hwnd, BUTTON_1), SW_SHOW);
            ShowWindow(GetDlgItem(hwnd, BUTTON_2), SW_HIDE);
            {
                HINSTANCE hLib = LoadLibrary("FirstDDL.dll");
                if (hLib != NULL)
                {
                    MYPROC func = (MYPROC) GetProcAddress(hLib, "SomeFunction");
                    if (func != NULL)
                    {
                        func("DLLs are easy");
                    }
                    FreeLibrary(hLib);
                }
                else
                {
                    MessageBox(hwnd, "Problem with DLL", "", MB_OK);
                }
            }
            break;

        case BUTTON_3:
            MessageBox(hwnd, "Starting", "", MB_OK);
            DialogBox(NULL, MAKEINTRESOURCE(MY_DIALOG), hwnd, (DLGPROC) DialogProcedure);
            MessageBox(hwnd, "The End", "", MB_OK);
            break;

        case BUTTON_4:
            EnableWindow(GetDlgItem(hwnd, BUTTON_4), FALSE);
            EnableWindow(GetDlgItem(hwnd, BUTTON_3), TRUE);
            break;

        case BUTTON_5:
        {
            HWND edit = GetDlgItem(hwnd, EDIT_WINDOW);
            INT length = GetWindowTextLength(edit);
            LPTSTR txt = new TCHAR[length + 1];
            GetWindowText(edit, txt, length + 1);
            HWND edit_2 = GetDlgItem(hwnd, EDIT_WINDOW2);
            length = GetWindowTextLength(edit_2);
            LPTSTR txt_2 = new TCHAR[length + 1];
            GetWindowText(edit_2, txt_2, length + 1);
            INT a,b,c;
            sscanf(txt,"%d",&a);
            sscanf(txt_2, "%d", &b);
            printf ("%d\n", a);
            printf ("%d\n", b);
            HINSTANCE hLib = LoadLibrary("FirstDDL.dll");
                if (hLib != NULL)
                {
                    MYPROC2 func = (MYPROC2) GetProcAddress(hLib, "addNumbers");
                    if (func != NULL)
                    {
                        c = func(a,b);
                        printf ("c = %d\n", c);
                    }

                    FreeLibrary(hLib);
                }
                else
                {
                    MessageBox(hwnd, "Problem with DLL", "", MB_OK);
                }
                char out[5];
                sprintf(out,"%d",c);
                MessageBox(hwnd,out,"",MB_OK);
        }
        break;

        case ID_FILE_EXIT:
            PostMessage(hwnd, WM_CLOSE, 0, 0);
            break;

        case ID_HELP:
            MessageBox(hwnd, TEXT("Help in progress"), "Title", MB_OK);
            break;
        }
        break;

    case WM_KEYUP:
        MessageBox(hwnd, TEXT("Some text"), "Title", MB_OK);
        break;

    case WM_DESTROY:
        PostQuitMessage(0);
        break;

    default:
        return DefWindowProc(hwnd, message, wParam, lParam);
    }
    return 0;
}

/* Dialog Procedure */
BOOL CALLBACK DialogProcedure(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
    case WM_INITDIALOG:
        CreateWindow(
            "BUTTON",
            "Dialog",
            WS_VISIBLE | WS_CHILD | BS_ICON,
            10, 100, 50, 50,
            hDlg,
            (HMENU) BUTTON_ICON,
            (HINSTANCE) GetWindowLongPtr(GetParent(hDlg), GWLP_HINSTANCE),
            NULL);
        {
            HICON h = LoadIcon((HINSTANCE) GetModuleHandle(0), MAKEINTRESOURCE(ID_ICON2));
            if (h == NULL)
            {
                MessageBox(hDlg, "There is no icon", "", MB_OK);
            }
            SendMessage(GetDlgItem(hDlg, BUTTON_ICON), BM_SETIMAGE, IMAGE_ICON, (LPARAM) h);
        }
        return TRUE;

    case WM_COMMAND:
        switch (LOWORD(wParam))
        {
        case MY_DIALOG_BUTTON:
        {
            HWND edit = GetDlgItem(hDlg, MY_TEXT_FIELD);
            INT length = GetWindowTextLength(edit);
            LPTSTR txt = new TCHAR[length + 1];
            GetWindowText(edit, txt, length + 1);
            SetWindowText(GetParent(hDlg), txt);
            delete[] txt;
            EndDialog(hDlg, 0);
        }
        return TRUE;
        }
        break;

    case WM_CLOSE:
    case WM_DESTROY:
        EndDialog(hDlg, 0);
        return TRUE;
    }
    return FALSE;

    return 0;
}
