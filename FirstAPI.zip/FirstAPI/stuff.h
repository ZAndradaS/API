#include <windows.h>

#define IDR_MYMENU 1001
#define ID_FILE_EXIT 9001
#define ID_HELP 9002
#define ID_ICON 9003
#define ID_ICON2 9004

#define BUTTON_1 9005
#define BUTTON_2 9006
#define BUTTON_3 9007
#define BUTTON_4 9008
#define BUTTON_5 9009
#define EDIT_WINDOW 9010
#define EDIT_WINDOW2 9011

#define MY_DIALOG 9020
#define MY_TEXT 9021
#define MY_DIALOG_BUTTON 9022
#define MY_TEXT_FIELD 9023
#define BUTTON_ICON 9024
